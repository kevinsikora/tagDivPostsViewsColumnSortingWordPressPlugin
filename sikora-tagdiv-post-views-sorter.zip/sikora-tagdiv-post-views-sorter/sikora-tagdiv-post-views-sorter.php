<?php
/**
 * Plugin Name:       Sikora TagDiv Post Views Sorter (Customization)
 * Plugin URI:        https://sikoracollective.com/
 * Description:       Makes the TagDiv Newspaper theme's "Views" column on the admin Posts screen sortable, so you can order posts by how many views they've received. Read-only: no database changes are made.
 * Version:           1.0.0
 * Requires at least: 4.2
 * Requires PHP:      5.6
 * Author:            Sikora Collective
 * Author URI:        https://sikoracollective.com/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       sikora-tagdiv-post-views-sorter
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Sikora_TagDiv_Post_Views_Sorter {

	/** Meta key the Newspaper theme uses to store view counts. */
	const META_KEY = 'post_views_count';

	/** Query var value used when sorting by views. */
	const ORDERBY = 'sikora_td_views';

	/** Column keys known to be (or detected as) the theme's Views column. */
	private static $view_columns = array( 'td_post_views' );

	public static function init() {
		if ( ! is_admin() ) {
			return;
		}
		add_action( 'current_screen', array( __CLASS__, 'register_screen_hooks' ) );
		add_action( 'pre_get_posts', array( __CLASS__, 'sort_by_views' ) );
	}

	/**
	 * Hook column filters for whichever post list screen is being viewed.
	 */
	public static function register_screen_hooks( $screen ) {
		if ( empty( $screen ) || 'edit' !== $screen->base || empty( $screen->post_type ) ) {
			return;
		}
		// Run last so the theme's Views column has already been added.
		add_filter( 'manage_' . $screen->post_type . '_posts_columns', array( __CLASS__, 'detect_view_columns' ), PHP_INT_MAX );
		add_filter( 'manage_posts_columns', array( __CLASS__, 'detect_view_columns' ), PHP_INT_MAX );
		add_filter( 'manage_' . $screen->id . '_sortable_columns', array( __CLASS__, 'make_sortable' ), PHP_INT_MAX );
	}

	/**
	 * Find the Views column key, whatever the theme version calls it.
	 */
	public static function detect_view_columns( $columns ) {
		foreach ( (array) $columns as $key => $label ) {
			$text = strtolower( wp_strip_all_tags( (string) $label ) );
			if ( false !== stripos( $key, 'view' ) || 'views' === trim( $text ) ) {
				self::$view_columns[] = $key;
			}
		}
		self::$view_columns = array_unique( self::$view_columns );
		return $columns;
	}

	public static function make_sortable( $sortable ) {
		foreach ( self::$view_columns as $key ) {
			// Descending first: most-viewed posts on the first click.
			$sortable[ $key ] = array( self::ORDERBY, true );
		}
		return $sortable;
	}

	/**
	 * Order the admin list query by the numeric view count.
	 * Posts without a view count are still included (treated as 0 / last).
	 */
	public static function sort_by_views( $query ) {
		if ( ! $query->is_main_query() || self::ORDERBY !== $query->get( 'orderby' ) ) {
			return;
		}

		$order = 'ASC' === strtoupper( (string) $query->get( 'order' ) ) ? 'ASC' : 'DESC';

		$meta_query = (array) $query->get( 'meta_query' );
		$meta_query[] = array(
			'relation'           => 'OR',
			'sikora_views_clause' => array(
				'key'     => self::META_KEY,
				'compare' => 'EXISTS',
				'type'    => 'NUMERIC',
			),
			array(
				'key'     => self::META_KEY,
				'compare' => 'NOT EXISTS',
			),
		);

		$query->set( 'meta_query', $meta_query );
		$query->set( 'orderby', array(
			'sikora_views_clause' => $order,
			'date'                => 'DESC',
		) );
	}
}

Sikora_TagDiv_Post_Views_Sorter::init();
